import{_ as r}from"./YRF1bdDM.js";import{_ as a}from"./B7ag2ZKb.js";import{_ as i}from"./DlAUqK2U.js";import{c,w as u,o as p,m as t,a as e}from"./hKSwsEg8.js";const l=`
Rejoindre IncluSens comme bénévole, c’est choisir de donner de son temps et de son énergie pour faire bouger les lignes de l’inclusion.

Nous recherchons aujourd’hui :

• des patients experts, **formés aux 40 heures d’éducation thérapeutique**, pour **partager leur expérience et accompagner** d’autres patients à travers nos ateliers ;

• des bénévoles motivés, prêts à nous aider à **déployer notre exposition** « Le handicap invisible en entreprise » partout en France, et **à animer des tables rondes** pour sensibiliser le grand public comme les professionnels.

Peu importe le temps que vous pouvez consacrer, chaque contribution a un impact.
`,d=`
Contactez nous via notre **formulaire en ligne** ou venez nous rencontrer lors de nos événements. (VOIR HELLO ASSO)

Nous serons ravies d’échanger avec vous et de vous accueillir dans notre équipe.
`,m={__name:"helper",setup(_){return(v,n)=>{const o=r,s=a;return p(),c(s,{subtitle:"Devenir bénévole","subtitle-style":"handwritten"},{default:u(()=>[t(o,{value:l,tag:"div"}),n[0]||(n[0]=e("p",{class:"text-center"},[e("br"),e("strong",null,"Comment nous rejoindre ?")],-1)),t(o,{value:d,tag:"div"})]),_:1})}}},x=i(m,[["__scopeId","data-v-b6adbeb3"]]);export{x as default};
